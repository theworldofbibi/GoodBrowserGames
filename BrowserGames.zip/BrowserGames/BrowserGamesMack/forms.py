from django import forms
from .models import *

class JogoForm(forms.ModelForm):
    class Meta:
        model = Jogo
        fields = '__all__'
        widgets = {
            'titulo': forms.TextInput(attrs={'class': 'form-control'}),
        }