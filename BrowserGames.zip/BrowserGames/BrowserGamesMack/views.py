import re
from django.http import HttpResponse
from django.shortcuts import render, redirect
from rest_framework import viewsets
from .models import *
from .serializers import *
from .forms import *
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .decorators import unauthenticated_user, allowed_users
from django.contrib.auth.models import Group
from django.core.exceptions import PermissionDenied
# Create your views here.
class JogoViewSet(viewsets.ModelViewSet):
    queryset = Jogo.objects.all()
    serializer_class = JogoSerializer


class CategoriaViewSet(viewsets.ModelViewSet):
    queryset = Categoria.objects.all()
    serializer_class = CategoriaSerializer




@unauthenticated_user
def registerPage(request):
    form = CreateUserForm()
    form2 = CreateProfileForm()
    
    if request.method == 'POST':
        if 'register' in request.POST:
            form = CreateUserForm(request.POST)
            form2 = CreateProfileForm(request.POST, request.FILES)
            if form.is_valid() and form2.is_valid():
                user = form.save()
                profile = form2.save(commit=False)
                profile.usuario = (user)
                profile.save()
                group = Group.objects.get(name='user')
                user.groups.add(group)
                login(request, user)
                return redirect('readAll')
            messages.info(request, 'informação digitada incorretamente')

        if 'login' in request.POST:
            username = request.POST.get('username')
            password = request.POST.get('password')
            user = authenticate(request, username = username, password = password)

            if user is not None:
                login(request, user)
                return redirect('readAll')
            else:
                messages.info(request, 'Login não encontrado ou usuário/senha incorreto')
    context = {'form': form, 'form2': form2}
    return render(request, "BrowserGamesMack/register.html", context)
    
def logoutUser(request):
    logout(request)
    return redirect('register')


@login_required(login_url='register')
@allowed_users(allowed_roles=['admin', 'user'])
def readAll(request):
    if request.method == 'POST':
        searched = request.POST['searched']
        jogo = Jogo.objects.all().filter(titulo__contains = (searched))
        if jogo:
            return render(request,'BrowserGamesMack/searchGame.html', {'listajogo':jogo})
        else:
            messages.info(request, 'Não foi localizado nenhum jogo contendo esse nome ') 
            return redirect('readAll') 
    listacomentarios = Comentario.objects.all().order_by('likes')[:5]
    listacategoria = Categoria.objects.order_by('id')
    listaJogos = Jogo.objects.order_by('id')
    context = {'listajogos': listaJogos, 'listacategoria': listacategoria, 'listacomentarios': listacomentarios}
    return render(request, 'BrowserGamesMack/index.html', context)

@login_required(login_url='register')
@allowed_users(allowed_roles=['admin', 'user'])

def profile(request):
    usuario = request.user.usuario
    form = CreateProfileForm(instance=usuario)
    if request.method == 'POST':
        form = CreateProfileForm(request.POST, request.FILES, instance=usuario)
        if form.is_valid():
            form.save()
            messages.info(request, 'Informações atualizadas com sucesso!')
    context = {'form': form}
    return render(request, 'BrowserGamesMack/profile.html', context)



@login_required(login_url='register')
@allowed_users(allowed_roles=['admin'])
def createJogo(request):
    form = JogoForm()
    if request.method == 'POST':
        form = JogoForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('readAll')

    context = {'form': form}
    
    return render(request, 'BrowserGamesMack/cadastrar.html', context)

@login_required(login_url='register')
@allowed_users(allowed_roles=['admin'])
def updateJogo (request, id):
    jogo = Jogo.objects.get(id = id)
    form = JogoForm(request.POST or None, instance=jogo)
    mydict = {
        'form': form,
        'jogo': jogo,
    }
    if form.is_valid() and request.method == 'POST':
        form.save()
        return redirect('viewjogo', titulo=jogo.titulo)

    return render(request, 'BrowserGamesMack/update.html', context=mydict)
@login_required(login_url='register')
@allowed_users(allowed_roles=['admin'])
def deleteJogo (request, id):
    jogo = Jogo.objects.get(id=id)

    if request.method == 'POST':
        jogo.delete()
        return redirect('readAll')
    
    return render(request, 'BrowserGamesMack/delete.html', {'jogo': jogo})

@login_required(login_url='register')
@allowed_users(allowed_roles=['admin', 'user'])
def viewJogo(request, titulo):
    jogo = Jogo.objects.get(titulo=titulo)
    listaComentarios = Comentario.objects.all().filter(jogo=jogo)
    avaliacao = ComentarioForm()
    numComent = jogo.comentarios.filter(jogo=jogo, usuario = request.user)
    liked = False
    if request.method == 'POST':
        if 'update' in request.POST:
            comentario = Comentario.objects.get(id = request.POST['update'])
            comentario.nota = request.POST['nota']
            comentario.comentario = request.POST['comentario']
            comentario.save()
        if 'review' in request.POST:
            comentario = Comentario.objects.get(id = request.POST.get('review'))
            if comentario.likes.filter(id = request.user.id).exists():
                comentario.likes.remove(request.user)
                liked = False
            else:
                comentario.likes.add(request.user)
                liked = True
        if 'create' in request.POST:
            # If there are any, raise an error
            avaliacao = ComentarioForm(request.POST)
            if avaliacao.is_valid():
                coment = avaliacao.save(commit=False)
                coment.usuario = request.user
                coment.jogo = (jogo)
                coment.save()
    context = {'avaliacao': avaliacao, 'listaComentarios': listaComentarios, 'jogo': jogo, 'numComent': numComent, 'liked': liked}
    return render(request, 'BrowserGamesMack/game.html', context)


def deleteComent (request, id, jogoid):
    comentario = Comentario.objects.get(id=id) 
    jogo = Jogo.objects.get(id=jogoid) 

    if request.method == 'POST':
        comentario.delete()
        return redirect('viewjogo', titulo=jogo.titulo)
    
    return render(request, 'BrowserGamesMack/deleteComent.html', {'comentario': comentario, 'jogo': jogo})


def deleteUser (request):
    usuario = request.user 

    if request.method == 'POST':
        usuario.delete()
        return redirect('register')
    
    return render(request, 'BrowserGamesMack/deleteUser.html', {'usuario': usuario})

@login_required(login_url='register')
@allowed_users(allowed_roles=['admin', 'user'])
def searchCat(request, titulo):
    cat = Categoria.objects.get(titulo=titulo)
    listajogos = Jogo.objects.all().filter(categoria=cat)
    return render(request, 'BrowserGamesMack/categoria.html', {'categoria': cat, 'listajogos': listajogos})


def viewRelatorio(request):
    listajogos = Jogo.objects.all().order_by('comentarios')
    listajogos2 = Jogo.objects.all().order_by('comentarios__nota')
    listaUsuarios = User.objects.all().order_by('comentario')
    listacategorias = Categoria.objects.all().order_by('jogo__comentarios')
    context = {'listajogos': listajogos, 'listajogos2': listajogos2, 'listaUsuarios': listaUsuarios, 'listacategorias': listacategorias}
    return render(request, 'BrowserGamesMack/report.html', context)