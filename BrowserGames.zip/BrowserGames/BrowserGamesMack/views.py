from django.http import HttpResponse
from django.shortcuts import render, redirect
from rest_framework import viewsets
from .models import *
from .serializers import *
from .forms import *
# Create your views here.
class JogoViewSet(viewsets.ModelViewSet):
    queryset = Jogo.objects.all()
    serializer_class = JogoSerializer


class CategoriaViewSet(viewsets.ModelViewSet):
    queryset = Categoria.objects.all()
    serializer_class = CategoriaSerializer




#class WebPageViewSet(viewsets.ModelViewSet, request):
#    queryset = Jogo.objects.order_by('id')
#    context = {'lista jogos': queryset}
#    render(request, 'core/index.html', context)
#    serializer_class = JogoSerializer




def readAll(request):
    listaJogos = Jogo.objects.order_by('id')
    context = {'listajogos': listaJogos}
    return render(request, 'BrowserGamesMack/index.html', context)

def createJogo(request):
    form = JogoForm(request.POST or None)
    mydict = {
        'form': form,
    }

    if form.is_valid():
        form.save()
        return redirect('readAll')
    return render(request, 'BrowserGamesMack/cadastrar.html', context=mydict)


def updateJogo (request, id):
    jogo = Jogo.objects.get(id = id)
    form = JogoForm(request.POST or None, instance=jogo)
    mydict = {
        'form': form,
        'jogo': jogo,
    }
    if form.is_valid() and request.method == 'POST':
        form.save()
        return redirect('readAll')

    return render(request, 'BrowserGamesMack/update.html', context=mydict)

def deleteJogo (request, id):
    jogo = Jogo.objects.get(id=id)

    if request.method == 'POST':
        jogo.delete()
        return redirect('readAll')
    
    return render(request, 'BrowserGamesMack/delete.html', {'jogo': jogo})

