from django.db import models

# Create your models here.
class Categoria(models.Model):
    titulo = models.CharField(null=False, max_length=80)
    

    def __str__(self):
        return self.titulo

class Jogo(models.Model):
    titulo = models.CharField(null=False, max_length=80)
    imagem = models.CharField(null=False, max_length=250)
    categoria = models.ForeignKey(Categoria, null=False, on_delete=models.CASCADE)
    Url_Video = models.URLField(null=False)
    Url_Jogo = models.URLField(null=False)

    def __str__(self):
        return self.titulo

