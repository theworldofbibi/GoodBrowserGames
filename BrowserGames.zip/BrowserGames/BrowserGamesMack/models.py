from django.db import models
from django.contrib.auth.models import User
from django_countries.fields import CountryField
from embed_video.fields import EmbedVideoField
from datetime import date
# Create your models here.
class Categoria(models.Model):
    titulo = models.CharField(null=False, max_length=80)
    

    def __str__(self):
        return self.titulo

class Jogo(models.Model):
    titulo = models.CharField(null=False, max_length=80, unique=True)
    imagem = models.URLField(null=True, blank=True, default="https://icon-library.com/images/default-profile-icon/default-profile-icon-24.jpg")
    categoria = models.ForeignKey(Categoria, null=False, on_delete=models.CASCADE)
    sinopse = models.CharField(null=True, max_length=250)
    Url_Video = EmbedVideoField(null=False)
    Url_Jogo = models.URLField(null=False)


class Usuario(models.Model):
    usuario = models.OneToOneField(User, null=True, on_delete=models.CASCADE)
    imagem = models.URLField(null=True, blank=True, default="https://icon-library.com/images/default-profile-icon/default-profile-icon-24.jpg")
    Telefone = models.CharField(null=True, max_length=11)
    data = models.DateField(null=True, default=date.today)
    pais = CountryField()
    estado =models.CharField(null=False, max_length=2)


class Comentario(models.Model):
    usuario = models.ForeignKey(User, null=True, on_delete=models.CASCADE)
    nota = models.CharField(null=False, max_length=2)
    comentario = models.TextField(null=True, blank=True, max_length=255)
    likes = models.ManyToManyField(User, related_name='likereview')
    jogo = models.ForeignKey(Jogo, null=False, on_delete=models.CASCADE, related_name="comentarios")

